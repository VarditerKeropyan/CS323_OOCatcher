#pragma once
#include "body.h"

class body_care
{
public:
    static void print(body* ptr);
    static void save(body* ptr);
};
