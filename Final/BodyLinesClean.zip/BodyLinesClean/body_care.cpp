#include "body_care.h"
#include <iostream>
#include <fstream>
#include <format>

using namespace std;

void body_care::print(body* ptr)
{
    cout << "\n";
    for (int i = 0; i < size(ptr->segs); i++)
        cout << format("seg[{}]: ({}, {})-({}, {})\n", i,
            ptr->segs[i]->int_x(), ptr->segs[i]->int_y(), ptr->segs[i]->ent_x(), ptr->segs[i]->ent_y());
}

void body_care::save(body* ptr)
{
    ofstream file("moves.dat", ios_base::trunc);

    for (int i = 0; i < size(ptr->segs); i++)
        file << ptr->segs[i]->int_x() << " " << ptr->segs[i]->int_y() << " " << ptr->segs[i]->ent_x() << " " << ptr->segs[i]->ent_y() << " ";
    file << "\n";
}
