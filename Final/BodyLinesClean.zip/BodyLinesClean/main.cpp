#include "body_care.h"
#include <iostream>

using namespace std;

int main()
{
    body dancer(20, 20, 10);

    for (int i = 4; i < 6; i++)
        cout << dancer.segs[i]->end_y() << endl;

    dancer.print(0);

    dancer.rotate(5, body_care::print);
    dancer.rotate(10, save);

    return 0;
}